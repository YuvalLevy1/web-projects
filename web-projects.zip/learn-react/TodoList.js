import React from 'react'
import TodoItem from './TodoItem'

export default function TodoList({todoList, toggleTodo}) {
    function getTaskSyntax() {
        if (todoList.filter(item => !item.completed).length > 1)
            return "tasks";
        return "task";
    }
    return (<>
        {todoList.map(item => <TodoItem key={item.id} todo={item} toggleTodo={toggleTodo}/>)}
        <div>{todoList.filter(item => !item.completed).length} {getTaskSyntax()} left</div>
        </>);
}
