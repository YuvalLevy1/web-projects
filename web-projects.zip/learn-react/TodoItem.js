import React from 'react'

export default function TodoItem({ todo, toggleTodo }) {
    
    return (
        <div>
            <label>
            <input type="checkbox" checked={todo.completed} onChange= {()=> toggleTodo(todo.id)} />
            {todo.content}
            </label>
        </div>
    )
}
