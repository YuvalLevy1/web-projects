import React, {useState, useRef, useEffect} from 'react';
import TodoList from "./TodoList";
import { v4 as uuidv4 } from 'uuid';

const LOCAL_STORAGE_LIST_KEY = "todoList"

function App() {

  const todoName = useRef();
  const [todos, setTodos] = useState([])
  
  useEffect(()=> {
      const storedList = JSON.parse(localStorage.getItem(LOCAL_STORAGE_LIST_KEY));
      if (storedList) {
        setTodos(storedList);
        console.log("reloaded")
      }
        
  }, []);

  useEffect(
    ()=> {localStorage.setItem(LOCAL_STORAGE_LIST_KEY, JSON.stringify(todos));}, [todos]);

  function addTodo(e) {
    const name = todoName.current.value;
    if (name === '') return;
    setTodos(oldTodoList => {
      console.log(oldTodoList);
      return [...oldTodoList, {id: uuidv4(), content: name, completed: false}];
    })

    todoName.current.value = '';
  }

  function toggleTodo(id) {
    const newTodos = [...todos];
    const todo = newTodos.find(todo => todo.id === id);
    todo.completed = !todo.completed;
    setTodos(newTodos);
  }

  return (<>
    <TodoList todoList={todos} toggleTodo={toggleTodo}/>
    <input ref={todoName} type="text" />
    <button onClick={addTodo}>Add item</button>
    <button onClick={() => setTodos([])}>Clear List</button>
  </>);
}

export default App;
