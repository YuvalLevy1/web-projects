import React, { Component } from 'react';
import 'bootstrap/dist/css/bootstrap.min.css';

export default class Counter extends Component {

    render() { 
        return <>
            <span className="badge bg-dark m-2">{this.formateCounter()}</span>
            <button onClick={this.props.onIncrement} className='btn btn-primary m-2'>+</button>
            <button onClick ={this.props.onDelete}className="btn btn-danger m-2">Delete</button>
            </>
    }

    formateCounter() {
        const value = this.props.counter.value;
        return value === 0 ? "Zero" : value
    }
}