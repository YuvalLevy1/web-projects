import React, { Component } from 'react';
import Counter from './counter'

export default class Counters extends Component {
    state = {
        counters : [
            { id: 1, value: 0}            
        ]
    } 

    handleDelete = (id) => {
        this.setState({
            counters: 
            this.state.counters.filter(counter => {return counter.id !== id;}
        )});
    }

    handleIncrement = (id) => {
        this.setState({
            counters:
            this.state.counters.map(counter => {
                if (counter.id === id)
                    counter.value++;
                return counter;
            })
        })
    }

    render() { 
        return (
         <>
            {this.state.counters.map(counter => <Counter key={counter.id} 
            counter={counter} onDelete={() => this.handleDelete(counter.id)}
             onIncrement={() => this.handleIncrement(counter.id)}/>)}
         </>
         )
    }
}