import Counters from "./components/counters"

function App() {
  return (
    <>
    <Counters/>
    </>
    )
}

export default App;
