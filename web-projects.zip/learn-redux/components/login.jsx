import React from "react";
import { useDispatch } from "react-redux";
import { login } from "../features/user";

function Login() {
  const dispatch = useDispatch();
  return (
    <>
      <button
        onClick={() =>
          dispatch(login({ name: "Yuval", age: 19, email: "bla" }))
        }
      >
        Login
      </button>
    </>
  );
}

export default Login;
