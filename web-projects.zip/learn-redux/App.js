import Profile from "./components/profile";
import Login from "./components/login";
import Logout from "./components/logout";
import ChangeColor from "./components/changeColor";

function App() {
  return (
    <div>
      <Profile />
      <Login />
      <Logout />
      <ChangeColor />
    </div>
  );
}

export default App;
