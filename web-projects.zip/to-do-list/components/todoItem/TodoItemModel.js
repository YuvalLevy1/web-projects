export default class TodoItem {
  constructor(content) {
    this.content = content;
    this.isFinished = false;
  }
}
