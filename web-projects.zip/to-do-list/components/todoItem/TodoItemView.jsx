import React from "react";

function TodoListItem(props) {
  const item = props.item;
  return (
    <span>
      <span>{item.content}</span>
      <input
        onChange={props.updateChecked}
        type="checkbox"
        checked={item.isFinished}
      ></input>
    </span>
  );
}

export default TodoListItem;
