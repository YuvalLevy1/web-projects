import React, { useRef } from "react";
import TodoListItem from "../todoItem/TodoItemView";
import { v4 as uuidv4 } from "uuid";
import { useSelector, useDispatch } from "react-redux";
import { toggleTodo, addTodo, removeTodo } from "../../features/todoListItems";

function TodoList() {
  const items = useSelector((state) => state.items.todoListItems);

  const dispatch = useDispatch();
  let text = useRef("");

  return (
    <>
      {items.map((item) => (
        <div key={uuidv4()}>
          <span>
            <TodoListItem
              item={item}
              updateChecked={() => dispatch(toggleTodo(item.id))}
            />
            <button onClick={() => dispatch(removeTodo(item.id))}>
              Delete
            </button>
          </span>
        </div>
      ))}
      <input ref={text}></input>
      <button
        onClick={() => {
          if (text.current.value) {
            dispatch(addTodo(text.current.value));
            text.current.value = "";
          }
        }}
      >
        Add todo
      </button>
    </>
  );
}

export default TodoList;
