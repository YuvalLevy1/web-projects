import { createSlice } from "@reduxjs/toolkit";
import { v4 as uuidv4 } from "uuid";

export const itemsSlice = createSlice({
  name: "items",
  initialState: { todoListItems: [] },
  reducers: {
    addTodo: (state, action) => {
      state.todoListItems.push({
        id: uuidv4(),
        content: action.payload,
        isFinished: false,
      });
    },
    removeTodo: (state, action) => {
      state.todoListItems = state.todoListItems.filter(
        (item) => item.id !== action.payload
      );
    },
    toggleTodo: (state, action) => {
      const item = state.todoListItems.find(
        (item) => item.id === action.payload
      );
      item.isFinished = !item.isFinished;
    },
  },
});

export const { addTodo, removeTodo, toggleTodo } = itemsSlice.actions;
export default itemsSlice.reducer;
