import React, { Component } from "react";
import TodoList from "./components/todoList/TodoListView";

class App extends Component {
  state = {};

  render() {
    return <TodoList />;
  }
}

export default App;
