export const BOARD_FULL_VALUE = 1;

function isBoardFull(board) {
    let isFull = true;
    for(let i = 0; i < board.data.length; i++) {
        for (let j = 0; j < board.data[i].length; j++) {
            if (board.data[i][j] === board.emptyValue)
                isFull = false;
        }
    }
    return isFull;
}

function didFillRows(board, player) {
    for (let i = 0; i < board.data.length; i++) {
        if (board.data[i][0] === board.data[i][1] && board.data[i][0] === board.data[i][2]) {
            return board.data[i][0] === player
        }
    }
    return false;
}

function didFillColumns(board, player) {
    for (let i = 0; i < board.data.length; i++) {
        if (board.data[0][i] === board.data[1][i] && board.data[0][i] === board.data[2][i]) {
            return board.data[0][i] === player
        }
    }
    return false;
}

function didFillSlants(board, player) {
    let slantFull = true;
    for (let i = 0; i < board.data.length; i++) {
        if (board.data[i][i] !== player)
            slantFull = false;
    }
    if (slantFull) {
        return true;
    }
    slantFull = true;

    for (let i = board.data.length - 1, j = 0; i > -1; i--, j++) {
        if (board.data[j][i] !== player)
            slantFull = false;
        }
    return slantFull;    
}

export function isOver(board, players) {
    let winner = board.emptyValue;
    players.forEach(player => {
        if (didFillColumns(board, player) ||
            didFillRows(board, player) ||
            didFillSlants(board, player))
        winner = player;
    });
    return isBoardFull(board) ? BOARD_FULL_VALUE : winner;
}