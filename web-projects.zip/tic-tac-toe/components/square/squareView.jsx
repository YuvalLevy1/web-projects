import React, { Component } from "react";
import "./square.css";

export default class Square extends Component {
  render() {
    return (
      <>
        <div className="col">{this.props.square.value}</div>
      </>
    );
  }
}
