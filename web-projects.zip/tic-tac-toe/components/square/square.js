export default class Square {
  constructor(value) {
    this.value = value;
  }
}
