import React, { Component } from "react";
import Square from "../square/squareView.jsx";
import Board from "./board.js";
import { v4 as uuidv4 } from "uuid";
import "bootstrap/dist/css/bootstrap.min.css";

export default class BoardView extends Component {
  state = {};

  constructor(props) {
    super(props);
    const board = new Board(this.props.emptyValue, this.props.size);
    this.state = { board };
  }

  render() {
    console.log(this.state.board.data);
    return (
      <>
        {this.state.board.data.map((row) => (
          <div key={uuidv4()} className="row">
            {row.map((square) => {
              return <Square key={uuidv4()} square={square} />;
            })}{" "}
          </div>
        ))}
      </>
    );
  }
}
