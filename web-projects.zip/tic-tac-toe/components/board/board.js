import Square from "../square/square";

export default class Board {
  constructor(emptyValue, size) {
    this.emptyValue = emptyValue;
    this.data = this.createBoard(size);
  }

  createBoard(size) {
    let board = [];
    for (let i = 0; i < size; i++) {
      board.push([]);
      for (let j = 0; j < size; j++) {
        board[i].push(new Square(this.emptyValue));
      }
    }
    return board;
  }

  markSquare(location, player) {
    const [x, y] = location;
    if (this.data[x][y] !== this.emptyValue) {
      return;
    }
    this.data[x][y] = new Square(player);
  }
}
