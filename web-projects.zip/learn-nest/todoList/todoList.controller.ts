import {
  Controller,
  Post,
  Body,
  Get,
  Param,
  Patch,
  Delete,
} from '@nestjs/common';

import { TodoListService } from './todoList.service';

@Controller('todoList')
export class TodoListController {
  private readonly todoListService: TodoListService;

  constructor(todoListService: TodoListService) {
    this.todoListService = todoListService;
  }

  @Post()
  addTodoItem(@Body('itemContent') itemContent: string) {
    const itemsTodo = this.todoListService.insertItem(itemContent);
    return { items: itemsTodo };
  }

  @Get()
  getTodoItems() {
    return { items: this.todoListService.getItems() };
  }

  @Get(':id')
  getTodoItem(@Param('id') itemId: String) {
    return { item: this.todoListService.getItem(itemId) };
  }

  @Patch(':id')
  toggleFinished(@Param('id') itemId: String) {
    return { item: this.todoListService.toggleItem(itemId) };
  }

  @Delete(':id')
  removeItemTodo(@Param('id') itemId: String) {
    this.todoListService.removeItem(itemId);
    return { items: this.todoListService.getItems() };
  }
}
