export class Item {
  public content: String;
  public isFinished: boolean;
  public id: String;

  constructor(content: String, isFinished: boolean, id: String) {
    this.content = content;
    this.isFinished = isFinished;
    this.id = id;
  }
}
