import { Injectable, NotFoundException } from '@nestjs/common';
import { Item } from './item.model';
import { v4 as uuidv4 } from 'uuid';

@Injectable()
export class TodoListService {
  private itemsTodo: Item[] = [];

  insertItem(content: String) {
    const newItem = new Item(content, false, uuidv4());
    this.itemsTodo.push(newItem);
    return this.itemsTodo;
  }

  removeItem(id: String) {
    const itemToRemove = this.getItem(id);
    const index = this.itemsTodo.indexOf(itemToRemove);
    this.itemsTodo.splice(index, 1);
  }

  getItems() {
    return this.itemsTodo;
  }

  getItem(id: String) {
    const todoItem = this.itemsTodo.find((item) => item.id === id);
    if (!todoItem) {
      throw new NotFoundException(
        `item with id: '${id}' does not exist in storage`,
      );
    }
    return todoItem;
  }

  toggleItem(id: String) {
    const item = this.getItem(id);
    item.isFinished = !item.isFinished;
    console.log();
    return item;
  }
}
